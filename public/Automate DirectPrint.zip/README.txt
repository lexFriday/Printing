# Automate DirectPrint (Arlechino Concepts Inc.)

Single standalone Windows application with Desktop GUI — No terminal, no Node.js needed!

## How to use:
1. Double-click "Automate DirectPrint.exe".
2. The DirectPrint Control Panel GUI window opens on your desktop.
3. Keep the window open or minimized in the background.
4. In your web browser, click "Direct Print" on any Delivery Receipt, Check, or Service Invoice page.
   The job instantly spools to your printer!

## Features:
- Clean standalone desktop GUI window
- Live hardware printer detection & selection
- Test print triggers for DR, Check, Service Invoice, and Check Voucher
- Real-time print activity history
