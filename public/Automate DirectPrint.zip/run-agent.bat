@echo off
start "" "%~dp0Automate DirectPrint.exe"
exit
