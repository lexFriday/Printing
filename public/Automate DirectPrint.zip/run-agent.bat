@echo off
title Automate DirectPrint Helper
cd /d "%~dp0"
echo ========================================================
echo   Automate DirectPrint Helper
echo ========================================================
echo   Starting Print Server on port 18890...
echo   Local URL: http://127.0.0.1:18890
echo ========================================================
echo.
"Automate DirectPrint.exe"
if errorlevel 1 (
  echo.
  echo [ERROR] Automate DirectPrint stopped.
  echo Check direct-print.log for details.
  pause
)
