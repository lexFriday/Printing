@echo off
title Automate DirectPrint (Node.js Mode)
cd /d "%~dp0"
echo Starting Automate DirectPrint via Node.js...
node agent.cjs --daemon
if errorlevel 1 (
  echo.
  echo [ERROR] Node.js failed to run agent.cjs.
  pause
)
