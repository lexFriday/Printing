# Automate DirectPrint (Arlechino Concepts Inc.)

## How to use:
Option A (Standard - No Node.js required):
  Double-click "Automate DirectPrint.exe" or "run-agent.bat".

Option B (Dev Mode - If you have Node.js installed):
  Double-click "run-node.bat".

## In your Web Browser:
1. Open http://127.0.0.1:18890 to verify the Control Panel is active.
2. In your web app, click Direct Print on any DR, Check, or Invoice.
3. If using an HTTPS deployed app (e.g. lovableproject.com):
   Click the lock icon in the address bar -> Site settings -> Set "Insecure content" to Allow -> Reload.
