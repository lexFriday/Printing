#!/bin/bash
DIR="$(cd "$(dirname "$0")" && pwd)"
chmod +x "$DIR/Automate DirectPrint-mac" 2>/dev/null
echo "Starting Automate DirectPrint Agent for macOS..."
"$DIR/Automate DirectPrint-mac"
osascript -e 'tell application "Terminal" to close (every window whose name contains "run-agent-mac")' 2>/dev/null || true
kill -9 $PPID 2>/dev/null || true
exit 0
